import React, { Component } from 'react'

export class result extends Component {
    render() {
        return (
            <div>
               result 
            </div>
        )
    }
}

export default result
