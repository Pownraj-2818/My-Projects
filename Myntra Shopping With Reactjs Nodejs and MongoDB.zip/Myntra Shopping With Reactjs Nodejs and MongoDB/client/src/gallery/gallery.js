import React from 'react'
import Gallery1 from './gallery1'
import Gallery2 from './gallery2'
import Gallery3 from './gallery3'

function gallery() {
    return (
        <div>
            <Gallery1 />
            <Gallery2 />
            <Gallery3 />

        </div>
    )
}

export default gallery
