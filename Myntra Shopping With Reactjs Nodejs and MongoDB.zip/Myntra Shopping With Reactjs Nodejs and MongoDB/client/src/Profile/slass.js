import React, { Component } from 'react'

export class slass extends Component {
    render() {
        return (
            <div>
                
            </div>
        )
    }
}

export default slass
