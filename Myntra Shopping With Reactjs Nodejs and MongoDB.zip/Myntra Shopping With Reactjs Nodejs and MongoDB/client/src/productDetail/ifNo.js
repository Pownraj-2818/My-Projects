import React, { Component } from 'react'

export class ifNo extends Component {
    render() {
        return (
            <div>
                
            </div>
        )
    }
}

export default ifNo
