import React, { Component } from 'react'
import Welcome from "./welcome"

export class button extends Component {
    render() {
        return (
            <div>
                <Welcome />
            </div>
        )
    }
}

export default button

